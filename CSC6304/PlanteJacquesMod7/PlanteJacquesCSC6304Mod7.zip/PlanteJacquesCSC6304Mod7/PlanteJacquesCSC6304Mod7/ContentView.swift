//
//  ContentView.swift
//  PlanteJacquesCSC6304Mod7
//
//  Created by Plante, Jacques on 12/4/24.
//

import SwiftUI

struct ContentView: View {
    @State private var totalTime = 0
    @State private var timerRunning = true
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        Text(formatTime(timeInterval: Double(totalTime)))
            .onReceive(timer) { _ in
                if timerRunning {
                    totalTime += 1
                }
            }
        Button(timerRunning ? "Stop the Clock!" : "Start the Clock!", action: {
            timerRunning.toggle()
        })
    }

    private func formatTime(timeInterval: TimeInterval) -> String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.minute, .second]
        formatter.unitsStyle = .positional
        formatter.zeroFormattingBehavior = .pad
        return formatter.string(from: timeInterval)!
    }
}

#Preview {
    ContentView()
}
