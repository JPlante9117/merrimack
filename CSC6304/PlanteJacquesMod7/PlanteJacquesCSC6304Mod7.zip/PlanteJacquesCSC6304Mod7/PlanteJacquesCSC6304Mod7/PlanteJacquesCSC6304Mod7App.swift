//
//  PlanteJacquesCSC6304Mod7App.swift
//  PlanteJacquesCSC6304Mod7
//
//  Created by Plante, Jacques on 12/4/24.
//

import SwiftUI

@main
struct PlanteJacquesCSC6304Mod7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
