//
//  PlanteJacquesCSC6304Mod7Tests.swift
//  PlanteJacquesCSC6304Mod7Tests
//
//  Created by Plante, Jacques on 12/4/24.
//

import Testing

struct PlanteJacquesCSC6304Mod7Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
