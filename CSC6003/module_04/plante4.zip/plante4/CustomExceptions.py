class EmptyDataException(Exception):
    pass

class SongNotFoundException(Exception):
    pass

class DuplicateSongException(Exception):
    pass