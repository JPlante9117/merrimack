-- Select everything from the Student table
SELECT * FROM SCHOOL.Student;