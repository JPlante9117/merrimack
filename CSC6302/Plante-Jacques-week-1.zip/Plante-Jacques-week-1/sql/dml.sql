-- Inserts into the Student table...
INSERT INTO Student (
    first_name,
    last_name,
    email_address,
    date_of_birth,
    student_grade,
    teacher_first_name,
    teacher_last_name,
    teacher_email,
    room_number,
    subject,
    class_grade
) 
-- ...these values
VALUES (
    'Jacques',
    'Plante',
    'plantejac@merrimack.edu',
    '1995-11-02',
    12,
    'Amanda',
    'Menier',
    'menieram@merrimack.edu',
    2,
    'Database Principles',
    'A'
);